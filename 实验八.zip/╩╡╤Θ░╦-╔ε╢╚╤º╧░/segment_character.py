#coding: utf-8
import cv2
import numpy as np
import os

character_dict = {0:"self_dataset\character1",
                  1:"self_dataset\character2",
                  2:"self_dataset\character3"} 

def crop_picture(image_path, character_label):
    # 读取图像并且二值化
    image = cv2.imread(image_path)
    image = cv2.GaussianBlur(image,(3,3),0)
    imgray = cv2.cvtColor(~image,cv2.COLOR_BGR2GRAY) 

    # 使用Canny算子提取边缘
    imgray = cv2.Canny(imgray,0,80)
    # 二值化
    _,thresh = cv2.threshold(imgray, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)  

    # 膨胀图像使汉字分开的笔划合在一起
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(3, 3))
    thresh_dilate = cv2.dilate(thresh,kernel,iterations=10)   

    # 提取文字图像边缘轮廓
    cnts = cv2.findContours(thresh_dilate.copy(),cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[0] 
    
    # 分割图片并且保存，比较小的点去除
    contour_num = 1
    for cnt in cnts:
        x, y, w, h = cv2.boundingRect(cnt)
        if (w < 40 and h < 40):
            continue
        
        # cv2.rectangle(image, (x,y), (x+w, y+h), (0, 255, 0), 2)
        image_part = image[y : y+h, x : x + w]
        image_part_gray = cv2.cvtColor(~image_part,cv2.COLOR_BGR2GRAY) 
        _, image_part= cv2.threshold(image_part_gray, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)  
        
        image_rotate(character_label, image_part, w, h,contour_num)
        cv2.imwrite(character_dict[character_label] + '\image%d'%contour_num+'ori'+'.jpg', image_part)
        contour_num += 1

# 将分割的图片从-30°到30°旋转，之后保存
def image_rotate(character_label, image_part, width, height,contour_num):
    for i in [-30, -20, -10, 10, 20, 30]:
        M = cv2.getRotationMatrix2D((width//2, height//2), i, 0.9)
        image_rotate = cv2.warpAffine(image_part, M, (round(width*1.2), round(height*1.2)), borderValue=(0, 0, 0))
        cv2.imwrite(character_dict[character_label] + '\image%d'%contour_num + '_rotate' +'_%d'%i +'.jpg',image_rotate)
        
if __name__ == "__main__": 
    # 防止文件夹被误删
    for i in range(3):
        dataset_file = "self_dataset\character{}".format(i+1)
        if not os.path.exists(dataset_file):
            os.makedirs(dataset_file)

    for i in range(3):
        picture_path = ["character{}.png".format(i+1), "character{}.jpg".format(i+1)]
        if os.path.exists(picture_path[0]):
            crop_picture(picture_path[0], i)
        elif os.path.exists(picture_path[1]):
            crop_picture(picture_path[1], i)
    