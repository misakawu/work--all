#coding=utf-8
import numpy as np
import package
import cv2
import os

def load(parameters, file):
    params = np.load(file)
    for i in range(len(parameters)):
        parameters[i].data = params[str(i)]


def load_MNIST(file, transform=False):
    file = np.load(file)
    X = file['X']
    Y = file['Y']
    if transform:
        X = X.reshape(len(X), -1)
    return X, Y
   
def pre_process(img_path):
    img = cv2.imread(img_path)
    imgray = cv2.cvtColor(~img,cv2.COLOR_BGR2GRAY)
 
    _,thresh = cv2.threshold(imgray,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)  # 大津阈值


    # 提取二值化图像的轮廓
    cnts = cv2.findContours(thresh.copy(),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[0]

    # 找到拥有最大外接矩形的轮廓，很可能是数字
    max_square = 0
    for cnt in cnts:
        x, y, w, h = cv2.boundingRect(cnt)
        if(w * h > max_square):
            max_square = w * h
            maxx, maxy, maxw, maxh = cv2.boundingRect(cnt)

    # 用正方形切割出数字，边长为长宽最大值
    length = max(maxw, maxh)
    img = thresh[maxy + round((maxh-length)/2) : maxy + round((maxh+length)/2),
                 maxx + round((maxw-length)/2) : maxx + round((maxw+length)/2)]

    img = cv2.resize(img, (20, 20))
    img = cv2.copyMakeBorder(img, 4, 4, 4, 4,cv2.BORDER_CONSTANT, value=0)
    
    return img

layers = [
        {'type': 'conv', 'shape': (8, 5, 5, 1)},
        {'type': 'relu'},
        {'type': 'maxpool', 'size': 2},
        {'type': 'conv', 'shape': (16, 5, 5, 8)},
        {'type': 'relu'},
        {'type': 'maxpool', 'size': 2},
        {'type': 'transform', 'input_shape': (-1, 4, 4, 16), 'output_shape': (-1, 256)},
        {'type': 'linear', 'shape': (256, 64)},
        {'type': 'relu'},
        {'type': 'linear', 'shape': (64, 10)},
    ]

if __name__ == "__main__": 
    X, Y = load_MNIST(r'./MNIST/testset/testset.npz', transform=True) 
    net = package.Net(layers)
    load(net.parameters,r'./MNIST/param.npz')
    
    while(True):
        try:
            image_path = input("输入图片的路径:")
            if(image_path == 'exit'):
                break
            assert(os.path.exists(image_path))
        except:
            print('文件不存在,检查路径是否输入错误,之后请重新输入')
        
        else:
            image = pre_process(image_path)

            cv2.namedWindow("Number", cv2.WINDOW_NORMAL)
            cv2.resizeWindow("Number", 200, 200)
            cv2.imshow('Number',image)
            cv2.waitKey(0)

            image = image.reshape(1,28,28,1)
            output = net.forward(image / 255)
            output = np.exp(output - output.max(axis=-1, keepdims=True)) 
            output = np.argmax(output/output.sum(axis=-1, keepdims=True))
            print("数字预测值为:{}".format(output))