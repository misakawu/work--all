import numpy as np
from random import randint
import cv2

file = np.load('./MNIST/trainset/trainset.npz')
data = file['X']

num_image = data[randint(0, data.shape[0])]
num_image = cv2.resize(num_image,None,fx=5,fy=5)

cv2.imshow('a',num_image)
cv2.waitKey(0)