import numpy as np
import cv2
import os
import package
import package.optim as optim

layers = [
        {'type': 'conv', 'shape': (8, 5, 5, 1)},
        {'type': 'relu'},
        {'type': 'maxpool', 'size': 2},
        {'type': 'conv', 'shape': (16, 5, 5, 8)},
        {'type': 'relu'},
        {'type': 'maxpool', 'size': 2},
        {'type': 'conv', 'shape': (16, 5, 5, 16)},
        {'type': 'relu'},
        {'type': 'maxpool', 'size': 2},
        {'type': 'transform', 'input_shape': (-1, 4, 4, 16), 'output_shape': (-1, 256)},
        {'type': 'linear', 'shape': (256, 64)},
        {'type': 'relu'},
        {'type': 'linear', 'shape': (64, 3)},
    ]

def save(parameters, save_as):
    dic = {}
    for i in range(len(parameters)):
        dic[str(i)] = parameters[i].data
    np.savez(save_as, **dic)

def load(parameters, file):
    params = np.load(file)
    for i in range(len(parameters)):
        parameters[i].data = params[str(i)]


def image_pre_process(image):
    # 阈值分割二值化
    image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    _,image = cv2.threshold(image,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)  # 大津阈值
    
    # 不失真缩放
    width, height = image.shape
    if(width > height):
        delta = (width - height)//2
        image = cv2.copyMakeBorder(image, 0, 0, delta, delta,cv2.BORDER_CONSTANT, value=0)
    elif(width < height):
        delta = (height - width)//2
        image = cv2.copyMakeBorder(image, delta, delta, 0, 0,cv2.BORDER_CONSTANT, value=0)

    image = cv2.resize(image, (60,60))
    image = np.reshape(image, (60,60,1))

    return image

def load_dataset(file):
    # 使用字典定义对应文件夹的标签，若有较多可以改成循环生成
    character_class_dic = {'self_dataset\character1' : np.array([1, 0, 0],dtype = np.uint8), 
                           'self_dataset\character2' : np.array([0, 1, 0],dtype = np.uint8), 
                           'self_dataset\character3' : np.array([0, 0, 1],dtype = np.uint8)}

    # 读取之后的图片和标签
    image = []
    label = []
    # 遍历存放数据集的文件夹，读取图片
    for rt,_,fl in os.walk(file, topdown=True):
        for nm in fl:
            character_image = cv2.imread(str(rt)+"\\"+str(nm))
            character_image = image_pre_process(character_image)
            image.append(character_image)
            label.append(character_class_dic[rt])
            # print("文件:",str(rt)+"\\"+str(nm))

    image = np.concatenate([image],axis=0) 
    label = np.concatenate([label],axis=0)

    return image, label

def train(net, loss_fn, batch_size, optimizer, load_file, save_as, times=1, retrain=False, transform=False):
    X, Y =  load_dataset('self_dataset')
    try:
        assert(len(X))
    except:
        print('汉字数据集为空,请使用segment_character.py文件分割汉字')
        
    else:
        data_size = X.shape[0]
        if not retrain and os.path.isfile(load_file): load(net.parameters, load_file)
        for loop in range(times):
            i = 0
            while i <= data_size - batch_size:
                x = X[i:i+batch_size]
                y = Y[i:i+batch_size]
                i += batch_size

                x = x / 255
                output = net.forward(x)
                batch_acc, batch_loss = loss_fn(output, y)
                eta = loss_fn.gradient()
                net.backward(eta)
                optimizer.update()
                print("loop: %d, batch: %5d, batch acc: %2.1f, batch loss: %.5f" % \
                    (loop, i, batch_acc*100, batch_loss))
            pass
        if save_as is not None: save(net.parameters, save_as)

if __name__ == "__main__": 
    loss_fn = package.CrossEntropyLoss()
    net = package.Net(layers)
    optimizer = optim.Adam(net.parameters, 0.005)
    param_file = './MNIST/param_self_data.npz'
    batch_size = 8
    train(net, loss_fn, batch_size, optimizer, param_file, param_file, times=20, retrain=True) 

    
    
