from .sgd import SGD
from .momentum import Momentum
from .rmsprop import RMSprpo
from .adam import Adam