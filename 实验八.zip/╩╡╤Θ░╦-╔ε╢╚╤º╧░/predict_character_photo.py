import numpy as np
import cv2
import package
import os

layers = [
        {'type': 'conv', 'shape': (8, 5, 5, 1)},
        {'type': 'relu'},
        {'type': 'maxpool', 'size': 2},
        {'type': 'conv', 'shape': (16, 5, 5, 8)},
        {'type': 'relu'},
        {'type': 'maxpool', 'size': 2},
        {'type': 'conv', 'shape': (16, 5, 5, 16)},
        {'type': 'relu'},
        {'type': 'maxpool', 'size': 2},
        {'type': 'transform', 'input_shape': (-1, 4, 4, 16), 'output_shape': (-1, 256)},
        {'type': 'linear', 'shape': (256, 64)},
        {'type': 'relu'},
        {'type': 'linear', 'shape': (64, 3)},
    ]

def load(parameters, file):
    params = np.load(file)
    for i in range(len(parameters)):
        parameters[i].data = params[str(i)]

def image_pre_process(image):
    # 阈值分割二值化
    image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    _,image = cv2.threshold(~image,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)  
    
    # 不失真缩放
    width, height = image.shape
    if(width > height):
        delta = (width - height)//2
        image = cv2.copyMakeBorder(image, 0, 0, delta, delta,cv2.BORDER_CONSTANT, value=0)
    elif(width < height):
        delta = (height - width)//2
        image = cv2.copyMakeBorder(image, delta, delta, 0, 0,cv2.BORDER_CONSTANT, value=0)

    image = cv2.resize(image, (60,60))
    image = np.reshape(image, (1,60,60,1))

    return image

def predict_image(image):
    image_copy = image_pre_process(image)
    image_copy = image_copy / 255.0
    output = net.forward(image_copy)
    output = np.exp(output - output.max(axis=-1, keepdims=True)) 
    output = np.argmax(output/output.sum(axis=-1, keepdims=True))
    return image_copy, output

def crop_picture(image_path):
    # 读取图像并且二值化
    image = cv2.imread(image_path) 
    image = cv2.GaussianBlur(image, (3,3), 0)
    imgray = cv2.cvtColor(~image,cv2.COLOR_BGR2GRAY)
    # 使用Canny算子提取边缘
    imgray = cv2.Canny(imgray, 0, 80)
    # 阈值分割
    _,thresh = cv2.threshold(imgray, 0, 255, cv2.THRESH_BINARY+cv2.THRESH_OTSU)  

    # 膨胀图像使汉字分开的笔划合在一起
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(3, 3))
    thresh_dilate = cv2.dilate(thresh,kernel,iterations=10)   
    

    # 提取图像轮廓
    cnts = cv2.findContours(thresh_dilate.copy(),cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[0] 
    
    image_list = []
    # 分割图片并且保存，比较小的点去除
    for cnt in cnts:
        x, y, w, h = cv2.boundingRect(cnt)
        if (w * h < 900):
            continue
        image_part = image[y : y + h, x : x + w]
        image_list.append(image_part)

    return image_list
    

f = open('test_pictures\character_dict.txt','r', encoding="utf-8")
character_list = f.readlines()
character_dict = {0:character_list[0], 
                  1:character_list[1], 
                  2:character_list[2]}

if __name__ == "__main__": 
    net = package.Net(layers)
    load(net.parameters, r'./MNIST/param_self_data.npz')

    while(True):
        try:
            image_path = input('请输入预测图片的路径:')
            if(image_path == 'exit'):
                break
            assert(os.path.exists(image_path)) 
        except:
            print('文件不存在,检查路径是否输入错误,之后请重新输入')
        
        else:
            image_list = crop_picture(image_path)
        
            predict_char = ''
            character_image = []
            for i in range(len(image_list)):
                character, predict_output = predict_image(image_list[i])
                character_image.append(character[0])
                predict_char += character_dict[predict_output].strip('\n')
        
            print("汉字预测值为:{}".format(predict_char))

            img_stack = np.hstack(character_image)
            cv2.imshow('image',img_stack)
            cv2.waitKey(0)

   