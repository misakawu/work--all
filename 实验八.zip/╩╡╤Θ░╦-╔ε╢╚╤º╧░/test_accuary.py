#coding=utf-8
import numpy as np
import package
import os

def load(parameters, file):
    params = np.load(file)
    for i in range(len(parameters)):
        parameters[i].data = params[str(i)]


def load_MNIST(file, transform=False):
    file = np.load(file)
    X = file['X']
    Y = file['Y']
    if transform:
        X = X.reshape(len(X), -1)
    return X, Y

layers = [
        {'type': 'conv', 'shape': (8, 5, 5, 1)},
        {'type': 'relu'},
        {'type': 'maxpool', 'size': 2},
        {'type': 'conv', 'shape': (16, 5, 5, 8)},
        {'type': 'relu'},
        {'type': 'maxpool', 'size': 2},
        {'type': 'transform', 'input_shape': (-1, 4, 4, 16), 'output_shape': (-1, 256)},
        {'type': 'linear', 'shape': (256, 64)},
        {'type': 'relu'},
        {'type': 'linear', 'shape': (64, 10)},
    ]
   
test_file = r'./MNIST/testset/testset.npz'
param_file =r'./MNIST/param.npz'

# 异常处理
try:
    assert(os.path.exists(param_file))
except:
    print('权值文件不存在,请先使用mnist_cnn.py进行训练')
try:
    if not os.path.exists(test_file):
        test_file = './MNIST/testset.npz'
        assert(os.path.exists(test_file))
except:
    print('测试集文件不存在,查看是否未解压MNIST文件夹中的testset.rar')

else:
    X, Y = load_MNIST(test_file, transform=True) 
    net = package.Net(layers)
    load(net.parameters, param_file)
    
    correct_num = 0

    for i in range(X.shape[0]):
        x = X[i].reshape(1,28,28,1)
        y = Y[i]
        # np.where返回一个元组
        y = np.where(y == 1)
        output = net.forward(x / 255)
        output = np.exp(output - output.max(axis=-1, keepdims=True)) 
        output = np.argmax(output/output.sum(axis=-1, keepdims=True))
        
        print("预测的第{}个数字, 预测的结果为:{}, 实际上数字的标签为:{}".format(i+1, output, y[0][0]))
        if(output == y):
            correct_num += 1
            

    accuary = correct_num/100
    print("模型在测试集上的准确率为:{}%".format(accuary))

# x = X[7].reshape(28,28)
# cv2.imshow('a',x)
# cv2.waitKey(0)